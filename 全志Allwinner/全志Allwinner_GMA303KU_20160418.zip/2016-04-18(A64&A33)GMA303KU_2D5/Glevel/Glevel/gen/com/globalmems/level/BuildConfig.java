/** Automatically generated file. DO NOT MODIFY */
package com.globalmems.level;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}